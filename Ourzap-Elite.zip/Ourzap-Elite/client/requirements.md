## Packages
react-markdown | For rendering AI responses with markdown support
framer-motion | For smooth message animations and transitions
date-fns | For formatting timestamps

## Notes
API uses SSE for chat streaming via POST /api/conversations/:id/messages
Glassmorphism effects require backdrop-filter support
