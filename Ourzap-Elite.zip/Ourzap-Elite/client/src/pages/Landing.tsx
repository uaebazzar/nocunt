import { useCreateConversation, useConversations } from '@/hooks/use-chat';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { MessageSquare, Zap, Shield, ArrowRight } from 'lucide-react';

export default function LandingPage() {
  const [, setLocation] = useLocation();
  const createConversation = useCreateConversation();
  const { data: conversations, isLoading } = useConversations();

  const handleStart = async () => {
    // If we have history, go to the latest one
    if (conversations && conversations.length > 0) {
      setLocation(`/chat/${conversations[0].id}`);
    } else {
      // Otherwise create new
      const newConv = await createConversation.mutateAsync();
      setLocation(`/chat/${newConv.id}`);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white flex flex-col overflow-hidden relative selection:bg-primary selection:text-black">
      {/* Background Gradients */}
      <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-5%] w-[40%] h-[40%] bg-blue-500/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Nav */}
      <nav className="p-6 md:p-8 flex justify-between items-center z-10">
        <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-black shadow-lg shadow-primary/25">
            <Zap className="w-5 h-5 fill-current" />
          </div>
          Ourzap AI
        </div>
        <a 
          href="https://github.com" 
          target="_blank" 
          className="text-sm font-medium text-white/60 hover:text-white transition-colors"
        >
          GitHub
        </a>
      </nav>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center text-center px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-4xl mx-auto space-y-8"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-primary/80 mb-4">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            Available Now: GPT-5 Architecture
          </div>

          <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.1]">
            Experience the <span className="text-gradient">Next Era</span><br />
            of Intelligence
          </h1>
          
          <p className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto leading-relaxed">
            A premium chat interface designed for power users. 
            Fast, fluid, and focused on what matters: your conversation.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={handleStart}
              disabled={createConversation.isPending || isLoading}
              className="px-8 py-4 rounded-full bg-primary text-black font-semibold text-lg hover:scale-105 active:scale-95 transition-all duration-200 shadow-xl shadow-primary/20 hover:shadow-primary/40 flex items-center gap-2 group"
            >
              {createConversation.isPending ? "Initializing..." : "Start Chatting"}
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <button className="px-8 py-4 rounded-full bg-white/5 text-white font-medium hover:bg-white/10 border border-white/10 transition-all">
              View Documentation
            </button>
          </div>
        </motion.div>

        {/* Features Grid */}
        <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl w-full px-4">
          <FeatureCard 
            icon={<MessageSquare className="text-blue-400" />}
            title="Real-time Streaming"
            desc="Experience fluid conversations with ultra-low latency SSE streaming response technology."
          />
          <FeatureCard 
            icon={<Zap className="text-amber-400" />}
            title="Smart Context"
            desc="The AI remembers previous messages, allowing for deep, multi-turn conversations."
          />
          <FeatureCard 
            icon={<Shield className="text-green-400" />}
            title="Secure & Private"
            desc="Your conversations are stored securely. Privacy by design, not by accident."
          />
        </div>
      </main>

      <footer className="p-8 text-center text-white/20 text-sm">
        &copy; {new Date().getFullYear()} Ourzap AI. Built with pure excellence.
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="p-6 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-colors text-left group">
      <div className="w-10 h-10 rounded-lg bg-black/50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
        {icon}
      </div>
      <h3 className="text-lg font-semibold mb-2 text-white/90">{title}</h3>
      <p className="text-sm text-white/50 leading-relaxed">{desc}</p>
    </div>
  );
}
