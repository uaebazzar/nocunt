import { useEffect, useRef, useState } from 'react';
import { useRoute } from 'wouter';
import { Sidebar } from '@/components/Sidebar';
import { MessageBubble } from '@/components/MessageBubble';
import { useConversation, useChatStream } from '@/hooks/use-chat';
import { Menu, Send, StopCircle, ArrowUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

export default function ChatPage() {
  const [match, params] = useRoute('/chat/:id');
  const conversationId = params?.id ? parseInt(params.id) : null;
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [input, setInput] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const { data: conversation, isLoading } = useConversation(conversationId);
  const { sendMessage, streamingContent, isStreaming, stopStream } = useChatStream(conversationId || 0);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  }, [input]);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation?.messages, streamingContent, isStreaming]);

  const handleSubmit = () => {
    if (!input.trim() || !conversationId) return;
    sendMessage.mutate(input);
    setInput("");
    if (textareaRef.current) textareaRef.current.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  if (!conversationId) {
    return (
      <div className="flex h-screen bg-black text-white items-center justify-center">
        <p>Select or create a conversation</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-[#050505] overflow-hidden">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative h-full w-full">
        {/* Header */}
        <header className="absolute top-0 left-0 right-0 h-16 bg-black/80 backdrop-blur-md border-b border-white/5 z-20 flex items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-2 text-white/70 hover:text-white transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-2">
              <div className="md:hidden w-6 h-6 rounded bg-primary flex items-center justify-center text-black text-xs font-bold">OZ</div>
              <h1 className="font-semibold text-white/90 truncate max-w-[200px] md:max-w-md">
                {conversation?.title || "Loading..."}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-xs text-white/40 uppercase tracking-widest font-medium">Online</span>
          </div>
        </header>

        {/* Chat Area */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto pt-20 pb-32 px-4 md:px-6 scroll-smooth"
        >
          <div className="max-w-3xl mx-auto min-h-full flex flex-col justify-end">
            {isLoading ? (
              <div className="flex items-center justify-center h-full text-white/20">
                <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full mr-3"></div>
                Loading conversation...
              </div>
            ) : (
              <>
                {/* Introduction for empty chats */}
                {conversation?.messages.length === 0 && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center justify-center py-20 text-center space-y-4 opacity-50"
                  >
                    <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-4">
                      <BotIcon className="w-8 h-8 text-white/80" />
                    </div>
                    <h2 className="text-xl font-medium text-white">How can I help you today?</h2>
                    <p className="text-sm text-white/50 max-w-sm">
                      I can help you analyze data, write code, or just chat about the universe.
                    </p>
                  </motion.div>
                )}

                {/* Message History */}
                <AnimatePresence initial={false}>
                  {conversation?.messages.map((msg) => (
                    <MessageBubble 
                      key={msg.id}
                      role={msg.role as 'user' | 'assistant'}
                      content={msg.content}
                    />
                  ))}
                  
                  {/* Streaming Message */}
                  {isStreaming && streamingContent && (
                    <MessageBubble 
                      role="assistant"
                      content={streamingContent}
                      isStreaming={true}
                    />
                  )}
                </AnimatePresence>
              </>
            )}
          </div>
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/95 to-transparent pt-10 pb-6 px-4 z-20">
          <div className="max-w-3xl mx-auto relative">
            <div className={cn(
              "relative bg-white/5 border border-white/10 rounded-[26px] p-2 pr-2 pl-5 flex items-end transition-all duration-300",
              input.length > 0 && "bg-white/10 border-white/20 shadow-[0_0_30px_-5px_rgba(241,176,0,0.1)]"
            )}>
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask anything..."
                rows={1}
                className="flex-1 bg-transparent border-none text-white text-[16px] placeholder:text-white/30 focus:ring-0 resize-none py-3 max-h-[150px] custom-scrollbar leading-relaxed"
                disabled={isStreaming}
              />
              
              <div className="flex items-center pb-1.5 pl-2">
                {isStreaming ? (
                  <button
                    onClick={stopStream}
                    className="w-10 h-10 rounded-full bg-red-500/20 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all duration-200"
                  >
                    <StopCircle className="w-5 h-5 fill-current" />
                  </button>
                ) : (
                  <button
                    onClick={handleSubmit}
                    disabled={!input.trim()}
                    className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 shadow-lg",
                      input.trim() 
                        ? "bg-primary text-black hover:scale-105 hover:shadow-primary/30 cursor-pointer" 
                        : "bg-white/10 text-white/20 cursor-not-allowed"
                    )}
                  >
                    <ArrowUp className="w-5 h-5 stroke-[3]" />
                  </button>
                )}
              </div>
            </div>
            
            <div className="text-center mt-3 text-[11px] text-white/20 font-medium">
              AI can make mistakes. Check important info.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function BotIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7v1a2 2 0 0 1-2 2h-1v3a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-3H5a2 2 0 0 1-2-2v-1a7 7 0 0 1 7-7h1V5.73A2 2 0 0 1 10 4a2 2 0 0 1 2-2z" />
    </svg>
  );
}
