import React from 'react';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import { Copy, Check, Volume2, Bot, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';

interface MessageBubbleProps {
  role: 'user' | 'assistant';
  content: string;
  isStreaming?: boolean;
}

export function MessageBubble({ role, content, isStreaming }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(content);
      utterance.onend = () => setSpeaking(false);
      setSpeaking(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex w-full mb-6",
        role === 'user' ? "justify-end" : "justify-start"
      )}
    >
      <div className={cn(
        "max-w-[85%] md:max-w-[75%] rounded-2xl p-4 md:p-5 text-[15px] leading-relaxed relative group shadow-lg transition-all duration-300",
        role === 'user' 
          ? "bg-white text-black rounded-br-sm" 
          : "glass-panel text-gray-100 rounded-bl-sm border-white/5"
      )}>
        {/* Avatar/Label (Optional visual cue) */}
        <div className={cn(
          "absolute -top-6 text-xs font-medium opacity-50 flex items-center gap-1",
          role === 'user' ? "right-0" : "left-0"
        )}>
          {role === 'user' ? (
            <>You <User className="w-3 h-3" /></>
          ) : (
            <><Bot className="w-3 h-3 text-primary" /> Ourzap AI</>
          )}
        </div>

        {/* Content */}
        <div className="prose prose-invert max-w-none prose-p:leading-relaxed prose-pre:my-2 prose-pre:bg-black/50 prose-pre:border prose-pre:border-white/10">
          {role === 'user' ? (
            <div className="whitespace-pre-wrap font-medium">{content}</div>
          ) : (
            <ReactMarkdown>{content}</ReactMarkdown>
          )}
          {isStreaming && (
            <span className="inline-flex gap-1 ml-2 items-center">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:-0.3s]"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:-0.15s]"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce"></span>
            </span>
          )}
        </div>

        {/* Action Buttons (AI Only) */}
        {role === 'assistant' && !isStreaming && (
          <div className="flex items-center gap-3 mt-3 pt-3 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <button 
              onClick={handleCopy}
              className="flex items-center gap-1.5 text-xs text-white/40 hover:text-primary transition-colors"
              title="Copy to clipboard"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
            <button 
              onClick={handleSpeak}
              className={cn(
                "flex items-center gap-1.5 text-xs transition-colors",
                speaking ? "text-primary animate-pulse" : "text-white/40 hover:text-primary"
              )}
              title="Read aloud"
            >
              <Volume2 className="w-3.5 h-3.5" />
              {speaking ? 'Speaking...' : 'Speak'}
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
